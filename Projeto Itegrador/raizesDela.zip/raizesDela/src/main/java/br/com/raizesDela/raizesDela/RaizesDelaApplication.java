package br.com.raizesDela.raizesDela;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RaizesDelaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RaizesDelaApplication.class, args);
	}

}
